Hi! I'm the creator, thanks for downloading the pre-release.

Getting errors? Time to fix them!

Replace the game's assets with one from the mod, which is in the mod's folder called Assets.

Replace Assets

Assets (Old) -> Assets (New)

Now that you've replaced them, you can play!
Delete this Readme (file) if you've read and done everything.