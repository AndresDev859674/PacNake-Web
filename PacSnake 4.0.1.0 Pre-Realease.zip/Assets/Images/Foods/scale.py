import os
from PIL import Image

# Function to resize images
def resize_images_in_directory(directory, new_size):
    for filename in os.listdir(directory):
        # Check if the file is an image
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif', '.webp')):
            # Full path of the image
            image_path = os.path.join(directory, filename)
            
            # Open the image
            with Image.open(image_path) as img:
                # Resize the image using LANCZOS (high-quality downsampling)
                resized_img = img.resize(new_size, Image.Resampling.LANCZOS)
                
                # Save the resized image (overwrite or save to a new folder)
                resized_img.save(image_path)
                
                print(f"Image {filename} resized to {new_size[0]}x{new_size[1]} pixels.")

# Get the current directory
current_directory = os.path.dirname(os.path.abspath(__file__))

# Ask the user for the desired size
try:
    width = int(input("Enter the desired width for the images: "))
    height = int(input("Enter the desired height for the images: "))
    new_size = (width, height)
except ValueError:
    print("Please enter valid integers for width and height.")
    exit()

# Resize images in the current directory
resize_images_in_directory(current_directory, new_size)

print("Resizing process completed.")